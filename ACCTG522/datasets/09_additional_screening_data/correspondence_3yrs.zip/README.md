# SEC correspondence extracts

Complete readable extracted text, not AI summaries, sentiment scores, findings of wrongdoing, or a complete record of regulatory interaction. Forms UPLOAD and CORRESP are preserved metadata labels; they do not alone prove sender, recipient, topic or outcome. Company indexes are chronological, not verified closed threads. Date references are candidates, not asserted response pairings. Not all letters are public/available; missing letters do not mean no SEC concerns.

PDF text-layer extraction preserves page boundaries; image-only/scant text requires OCR/manual review and is not published as successful text. No OCR pipeline was run. Unsupported, missing and uncertain attachments stay recorded in the summary/pending list. Quoted comments in responses are retained. Best-effort table rows use vertical-bar cell separators; column relationships may be imperfect. Consult linked SEC originals. Raw PDFs/HTML/submissions and audit artifacts stay centrally, available on request.

CSV is UTF-8 without BOM with quoted fields; import CIK/accession as strings in Alteryx/Excel. Paths are package-relative. Each successful text SHA-256 is recorded. Source labels/openings are verbatim excerpts, not invented issue summaries. Scope is in export_manifest.json. Pilot sizes do not represent full-corpus sizes.
